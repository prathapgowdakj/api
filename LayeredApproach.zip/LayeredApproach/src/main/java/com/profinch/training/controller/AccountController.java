package com.profinch.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.profinch.training.repository.Account;
import com.profinch.training.service.AccountService;

@RestController
public class AccountController {

	@Autowired
	AccountService accountService;
	
	@GetMapping("/")
	public String login(){
	 		return "Welcome to Login page";
	}
	
	@PostMapping("/add")
	public Account createAccount(@RequestBody Account acc)
	{
		return accountService.createAccount(acc);
	}
	
	@GetMapping("/fetchall")
	public List<Account> getAllAccounts(){
		return accountService.getAllAccounts() ;
	}
	
	@GetMapping("/fetch/{name}")
	public Account getAccountByname(@PathVariable String name)
	{
		return accountService.getAccountByname(name);
	}
	
	@GetMapping("/fetch/{name}/{type}")
	public Account getAccountBynameandtype(@PathVariable String name, @PathVariable String type)
	{
		return accountService.getAccountBynameandtype(name, type);
	}
	
	@GetMapping("/fetchq/{name}")
	public List<Account> getAccounts(@PathVariable String name)
	{
		return accountService.getAccounts(name);
	}
	
//	@PutMapping("/update/{id}")
//	public Account updateAccount(@PathVariable int id, @RequestBody Account acc)
//	{
//		return accountService.updateAccount(id, acc);
//	}
//	
//	@GetMapping("/fetch/{id}")
//	public Account getAccountById(@PathVariable int id) {
//		return accountService.getAccountById(id);
//	}
//	
	@DeleteMapping("/delete")
	public void deleteAccount(@RequestParam int id)
	{
		accountService.deleteAccount(id);
	}
	
}
