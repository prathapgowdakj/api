package com.profinch.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.profinch.training.repository.Account;
import com.profinch.training.repository.AccountRepository;

@Service
@Transactional
public class AccountService {
	
	@Autowired
	AccountRepository accountRepository;
	
	
	public Account createAccount(Account acc)
	{
		return accountRepository.save(acc);
	}

	
	public List<Account> getAllAccounts(){
		return accountRepository.findAll();
	}
	
	
	public Account getAccountByname(String name)
	{
		return accountRepository.findByAcctHoldername(name);
	}
	
	
	public Account getAccountBynameandtype(String name, String type)
	{
		return accountRepository.findByAcctHoldernameAndAcctTypename(name, type);
	}
	
	public List<Account> getAccounts(String name)
	{
		return accountRepository.findAccounts(name);
	}
	
//	public Account updateAccount(int id, Account acc)
//	{
//		return accountRepository.updateAccount(id, acc);
//	}
//	
//	public Account getAccountById(int id)
//	{
//		return accountRepository.getAccountById(id);
//	}
//	
	public void deleteAccount(int id)
	{
		accountRepository.deleteById(id);
	}
//	
//	@Value("${service.url}")
//	private String serviceUrl;
//	
//	public void callservice() {
//		System.out.println("service url"+serviceUrl);
//	}
}
