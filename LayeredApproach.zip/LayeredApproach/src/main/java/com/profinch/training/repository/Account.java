package com.profinch.training.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Account {
	
	@Id
	@GeneratedValue
	private int id;
	
	@Column(name="name")
	private String acctHoldername;
	
	@Column(name="type")
	private String acctTypename;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAcctHoldername() {
		return acctHoldername;
	}
	public void setAcctHoldername(String acctHoldername) {
		this.acctHoldername = acctHoldername;
	}
	public String getAcctTypename() {
		return acctTypename;
	}
	public void setAcctTypename(String acctTypename) {
		this.acctTypename = acctTypename;
	}
	public Account(int id, String acctHoldername, String acctTypename) {
		super();
		this.id = id;
		this.acctHoldername = acctHoldername;
		this.acctTypename = acctTypename;
	}
	public Account() {
		super();
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", acctHoldername=" + acctHoldername + ", acctTypename=" + acctTypename + "]";
	}
	
	
	
	
	

}
