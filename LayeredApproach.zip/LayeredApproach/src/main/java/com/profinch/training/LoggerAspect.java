//package com.profinch.training;
//
//import java.util.List;
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.After;
//import org.aspectj.lang.annotation.AfterReturning;
//import org.aspectj.lang.annotation.AfterThrowing;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
//import org.aspectj.lang.annotation.Pointcut;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.Configuration;
//
//import com.profinch.training.repository.Account;
//
//
//@Aspect
//@Configuration
//public class LoggerAspect {
//		
//	Logger log=LoggerFactory.getLogger(LoggerAspect.class);
//	
//	/*@Before(" execution (* com.profinch.training.controller.AccountController.createAccount(..))")
//	public void logmethodbeforecall(JoinPoint name)
//	{
//		log.info("method called{}",name.getSignature());
//	}
//	
//	@After(" execution (* com.profinch.training.controller.AccountController.createAccount(..))")
//	public void logmethodaftercall(JoinPoint name)
//	{
//		log.info("method called{}",name.getSignature());
//	}
//	
//	@AfterReturning(value=" execution (* com.profinch.training.controller.AccountController.getAllAccounts(..))",returning="account")
//	public void logmethodafterreturncall(JoinPoint name, List<Account> account)
//	{
//		log.info("method called{}",name.getSignature());
//		log.info("account size{}",account.size());
//	}
//	
//	@AfterThrowing(value=" execution (* com.profinch.training.controller.AccountController.updateAccount(..))",throwing="exception")
//	public void logmethodafterthrowcall(JoinPoint name, Exception exception)
//	{
//		log.info("method called{}",name.getSignature());
//		log.info("exception captured{}",exception.getMessage());
//	}*/
//	
//	
//	@Pointcut("execution (* com.profinch.training.controller.AccountController.*(..))")
//	public void dummymethod()
//	{
//		
//	}
//	
//	@Around("dummymethod()")
//	public void aroundcall(ProceedingJoinPoint jp) throws Throwable {
//		
//		log.info("method before call{}",jp.getSignature().getName());
//		jp.proceed();
//		log.info("method after call{}",jp.getSignature().getName());
//		
//	}
//
//}
