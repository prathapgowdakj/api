package com.profinch.training.repository;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository extends JpaRepository<Account,Integer>
{
	
	
	public Account findByAcctHoldername(String name);
	
	public Account findByAcctHoldernameAndAcctTypename(String name, String type);
	
	@Query("select s from Account s where s.acctHoldername=?1")
	public List<Account> findAccounts(String name);
}

	
//	Logger log=LoggerFactory.getLogger(AccountRepository.class);
	
//	@Autowired
//	JdbcTemplate jdbcTemplate ;
	
	
//	static List<Account> list=new ArrayList<Account>();
//	
//	static
//	{
//		list.add(new Account(1,"abc","SA"));
//	}
	
	
//	public Account createAccount(Account acc)
//	{
//		log.info("repository layer");
//		//list.add(acc);
//		
//		int status=jdbcTemplate.update("insert into account values(?,?,?)" ,new Object[] { acc.getId(), 
//				acc.getAcctHoldername(),
//				acc.getAcctTypename()});
//		
//		if(status==1)
//		return acc;
//		else
//			return acc;	
//	}
//	
//	public List<Account> getAllAccounts(){
//		
//		return jdbcTemplate.query("select * from account",new BeanPropertyRowMapper(Account.class));
//		
//		//return list;
//	}
	
	
//	public Account updateAccount(int id, Account acc)
//	{
//	
//	Account upAcc=getAccountById(id);
//
//	if(upAcc!=null)
//	{
//	log.info("account id:{} available",acc.getId());
//	
//	upAcc.setAcctHoldername(acc.getAcctHoldername());
//
//	if(acc.getAcctTypename().equalsIgnoreCase("SA")||
//	acc.getAcctTypename().equalsIgnoreCase("TA"))
//	upAcc.setAcctTypename(acc.getAcctTypename());
//	else
//	throw new RuntimeException("Account type is not valid");
//	}
//	return upAcc;
//	}
//	
//	
//	public Account getAccountById(int id)
//	{
//	Account acc=null;
//	for(Account acc1:list)
//	{
//	if(id==acc1.getId())
//	{
//	acc=acc1; break; }
//	}
//	if(acc==null)
//	log.info("account id:{} not available",id);
//	return acc;
//	}
//
//	
//	public void deleteAccount(int id)
//	{ 
//	Account dacc=getAccountById(id);
//	list.remove(dacc);
//	}
//



