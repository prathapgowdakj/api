package com.profinch.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LayeredApproachApplicationTests {

	@Test
	void contextLoads() {
	}

}
